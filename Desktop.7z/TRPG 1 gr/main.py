import os
import shop  # импортируем файл shop.py


def show_menu():
    """
    Показывает главное меню
    Из него вызывается функция начала игры
    Из него завершается вся программа
    TODO:
        Настройки: цвет текста
        Сохранение/загрузка
    """

    # главный цикл меню, завершается правильным выбором
    while True:
        os.system("cls")
        print("1 - Начать новую игру")
        print("2 - Выйти")
        answer = input("Введите номер ответа и нажмите ENTER ")
        if answer == "1":
            start_game()
            break
        elif answer == "2":
            print("Выходим из игры")
            break
    print("Выходим из меню! Пока!")


def start_game():
    """
    Создает персонажа:
        player_name - имя игрока
        player_money - деньги игрока 
        player_hp - жизни игрока, >= 0 иначе игра заканчивается
        player_xp - опыт игрока
        player_potions - зелья, которые при использовании добавляют player_hp
    Запускает игру
    Игра контролируется переменной is_game
    """

    # создаем игрока
    player_name = input("Введите имя игрока и нажмите ENTER ")
    if not player_name: player_name = "Ктото Такой"
    player_money = 50
    player_hp = 100
    player_xp = 0
    player_potions = 0

    # главный цикл игры
    is_game = True
    while is_game:
        os.system("cls")

        # печтаем персонажа
        print(f"имя: {player_name}")
        print(f"жизни: {player_hp}")
        print(f"деньги: {player_money}")
        print(f"опыт: {player_xp}")
        print(f"зелья: {player_potions}")

        # печатаем ситуацию
        print(f"{player_name} приехал к камню.")

        # печатаем выборы
        print("1 - Поехать на битву с разбойниками")
        print("2 - Поехать играть в кости")
        print("3 - Поехать в лавку алхимика")

        # получаем ответ
        answer = input("Введите номер ответа и нажмите ENTER ")

        # проверяем ответ
        if answer == "1":
            print("Поехал на битву")
        elif answer == "2":
            print("Поехал играть в кости")
        elif answer == "3":
            shop.shop(player_name, player_money, player_hp, player_xp, player_potions)

        input("ENTER - дальше")


show_menu()  # запуск программы
