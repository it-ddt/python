import os


def shop(player_name, player_money, player_hp, player_xp, player_potions):
    os.system("cls")

    # печтаем персонажа
    print(f"имя: {player_name}")
    print(f"жизни: {player_hp}")
    print(f"деньги: {player_money}")
    print(f"опыт: {player_xp}")
    print(f"зелья: {player_potions}")

    # печатаем ситуацию
    print(f"{player_name} приехал в лавку")

    # печатаем выборы
    print("1 - Купить зелье за 10 монет")
    print("2 - Уехать к камню")

    # проверяем выбор
    answer = input("Введите номер варианта и нажмите ENTER ")



    input("++++++++++++++")
