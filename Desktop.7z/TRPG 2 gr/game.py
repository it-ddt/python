import os
import shop
import player


def start_new_game():
    """
    Создает персонажа:
        имя
        здоровье
        деньги
        зелья
    """
    # создаем персонажа
    player_name = input("Введите имя игрока и нажмите ENTER ")
    if not player_name:
        player_name = "Безымянный"
    player_hp = 100
    player_money = 50
    player_potions = 0

    # запускаем главный цикл игры
    is_game = True
    while is_game:
        os.system("cls")
        player.show_player_stats(player_name, player_hp, player_money, player_potions)
        
        print("-- ситуация:")
        print(f"{player_name} приехал к камню.")
        
        print("-- варианты:")
        print("1 - Поехать на битву")
        print("2 - Поехать играть в кости")
        print("3 - Поехать в лавку алхимика")
        print("0 - Выйти в главное меню")
        
        answer = input("Введите номер выианта и нажмите ENTER ")
        if answer == "1":
            pass
        elif answer == "2":
            pass
        elif answer == "3":  # вариант с магазином
            shop.visit_shop(player_name, player_hp, player_money, player_potions)
        elif answer == "0":  # выход в меню
            is_game = False