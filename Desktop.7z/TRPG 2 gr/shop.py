import os
import player


def visit_shop(player_name, player_hp, player_money, player_potions):
    """
    Печатаем персонажа
    Покупаем зелья, тратим деньги
    Варианты:
        Купить зелье (цена?)
        Уехать к камню
    """
    os.system("cls")
    player.show_player_stats(player_name, player_hp, player_money, player_potions)
    input("+++++++++++++")