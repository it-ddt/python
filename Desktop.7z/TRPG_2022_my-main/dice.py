import os


def dice(is_game, player_name, player_hp, player_money, player_potions):
    """
    выбор играть или уехать
    делать ставку
    не играть, если денег нет
    """
    os.system("cls")
    print(f"{player_name} съездил поиграть в кости")
    input("ENTER - дальше")
