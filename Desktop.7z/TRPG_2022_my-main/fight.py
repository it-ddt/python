import os


def fight(is_game, player_name, player_hp, player_money, player_potions):
    """
    сделать разбойника
    обмениваться ударами, пока кто-то не проиграет
    если есть зелья, их можно пить и лечиться
    """
    os.system("cls")
    print(f"{player_name} неудачно подрался с разбойником! Это провал!")
    is_game = False
    input("ENTER - продолжить")
    