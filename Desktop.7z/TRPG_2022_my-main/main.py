import os
import fight  # файл fight.py
import dice  # файл dice.py
import shop  # файл shop.py


def main_menu():
    """
    Показывает главное меню
    Из него запускается новая игра или завершается программа
    Нужна ли ASCII графика?
    TODO: сохранение и загрузка игры
    """

    # главный цикл меню
    while True:
        os.system("cls")
        print("1 - Новая игра")
        print("2 - Выход")
        answer = input("Введите номер варианта и нажмите ENTER: ")
        if answer == "1":
            start_game()
        elif answer == "2":
            print("Пока!")
            break


def start_game():
    """
    Создает персонажа из четырех переменных:
        player_name - Имя персонажа
        player_hp - Здоровье персонажа, если <= 0, то персонаж проигрывает
        player_money - Деньги персонажа, >= 0
        player_potions - Зелья лечения, при использовании добавляют player_hp
    Запускает новую игру с этим персонажем
    TODO:
        создание персонажа в отдельную функцию
        печать статов персонажа в отдельную функцию  
    """

    # создаем персонажа
    player_name = input("Как зовут вашего персонажа? ")
    if not player_name: player_name = "Кто Такойто"
    player_hp = 100
    player_money = 500
    player_potions = 0
    is_game = True

    # главный цикл игры
    while is_game:
        os.system("cls")
        
        print("- персонаж:")
        print(f"имя: {player_name}")
        print(f"здоровье: {player_hp}")
        print(f"деньги: {player_money}")
        print(f"зелья: {player_potions}")
        
        print("\n- ситуация:")
        print(f"{player_name} приехал к камню. Перед ним три дороги:")
        
        print("\n- варианты:")
        print("1 - битва с разбойником")
        print("2 - игра в кости")
        print("3 - лавка алхимика")
        print("0 - Выйти в главное меню")
        answer = input("\nВведите номер варианта и нажмите ENTER: ")
            
        # битва
        if answer == "1":
            fight.fight(is_game, player_name, player_hp, player_money, player_potions)
        
        # игра в кости
        elif answer == "2":
            dice.dice(is_game, player_name, player_hp, player_money, player_potions)
        
        # магазин алхимика
        elif answer == "3":
            shop.shop(is_game, player_name, player_hp, player_money, player_potions)

        # выход в главное меню
        elif answer == "0":
            is_game = False

    # здесь игра заканчивается и вызывается меню
    print("Конец игры")
    input("нажмите ENTER чтобы продолжить")
    main_menu()


# программа запускается здесь
main_menu()
