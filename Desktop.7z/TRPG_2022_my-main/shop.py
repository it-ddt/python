import os


def shop(is_game, player_name, player_hp, player_money, player_potions):
    """
    FIXME: деньги и зелья при следующем заходе в магазин сбрасываются до изначальных
    """
    while True:
        os.system("cls")
        print(f"имя: {player_name}")
        print(f"здоровье: {player_hp}")
        print(f"деньги: {player_money}")
        print(f"зелья: {player_potions}")
        print("----------")
        print(f"{player_name} приехал в лавку алхимика.")
        print("1 - Купить зелье за 200 монет")
        print("2 - Поехать к камню")

        answer = input("Введите номер варианта и нажмите ENTER: ")

        if answer == "1":
            if player_money >= 200:
                player_money -= 200
                player_potions += 1
                print(f"{player_name} купил зелье")
            else:
                print("У вас нет столько монет!")
            input("ENTER - дальше")
        elif answer == "2":
            break